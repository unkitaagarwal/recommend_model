from flask import Flask, request, jsonify
import pandas as pd
import json
import ast

app = Flask(__name__)

def load_data():
    try:
        df = pd.read_csv('foodlist7 - foodlist7 (3).csv')
        # Replace NaN with empty strings or a default value
        df = df.fillna('')
        df['allergy'] = df['allergy'].fillna("[]")
        df['image_url'] = df['image_url'].fillna("https://example.com/placeholder.jpg")
        df = df.drop_duplicates(subset='Dish')
        df['cuisines'] = df['cuisines'].apply(lambda x: ast.literal_eval(x.replace("'", '"') if isinstance(x, str) else x))
        df['allergy'] = df['allergy'].apply(lambda x: ast.literal_eval(x.replace("'", '"') if isinstance(x, str) else x))

        return df
    except Exception as e:
        print(f"Error loading CSV: {e}")
        return pd.DataFrame(SAMPLE_DATA)

def calculate_total_calories(meal):
    protein_calories = meal['Protein (g)'] * 4
    carb_calories = meal['Carbohydrates (g)'] * 4
    fat_calories = meal['Fat (g)'] * 9
    return protein_calories + carb_calories + fat_calories

@app.route('/recommend', methods=['POST'])
def handle_recommendations():
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No JSON data provided"}), 400

        num_meals = data.get('num_meals', 3)
        daily_target = data.get('daily_target', 2000)
        preferred_cuisines = data.get('cuisines', [])
        allergies = data.get('allergies', [])

        # Load and prepare data
        df = load_data()
        meals = df.to_dict('records')

        # Add total calories to each meal
        for meal in meals:
            meal['Total Calories'] = calculate_total_calories(meal)

        # Filter meals based on cuisine and allergies
        suitable_meals = []
        for meal in meals:
            cuisine_match = not preferred_cuisines or any(cuisine in meal['cuisines'] for cuisine in preferred_cuisines)
            allergy_safe = not any(allergy in meal['allergy'] for allergy in allergies)

            if cuisine_match and allergy_safe:
                suitable_meals.append(meal)

        if not suitable_meals:
            return jsonify({
                "message": "No meals found matching criteria. Returning default meal.",
                "meal_sections": [[] for _ in range(num_meals)]
            })

        # Create recommendations as sections
        meal_sections = []
        target_per_meal = daily_target / num_meals
        used_meals = set()

        # Create num_meals sections
        for section in range(num_meals):
            section_meals = []
            remaining_meals = [m for m in suitable_meals if m['Dish'] not in used_meals]

            if not remaining_meals:
                break

            # Sort by how close they are to target calories
            remaining_meals.sort(key=lambda x: abs(x['Total Calories'] - target_per_meal))

            # Get top 6 options for this section
            meal_options = remaining_meals[:6]
            for meal in meal_options:
                section_meals.append({
                    'Dish': meal['Dish'],
                    'Total Calories': meal['Total Calories'],
                    'Protein (g)': meal['Protein (g)'],
                    'Fat (g)': meal['Fat (g)'],
                    'Carbohydrates (g)': meal['Carbohydrates (g)'],
                    'Cuisines': meal['cuisines'],
                    'Allergies': meal['allergy'],
                    'image':meal['image_url']
                })



            meal_sections.append(section_meals)
            if meal_options:
                used_meals.add(meal_options[0]['Dish'])

        return jsonify({
            "meal_sections": meal_sections,
            "total_sections": len(meal_sections),
            "recommendations_per_section": len(meal_sections[0]) if meal_sections else 0,
            "daily_target": daily_target,
            "total_calories": sum(meal['Total Calories'] for section in meal_sections for meal in section[:1])
        })

    except Exception as e:
        return jsonify({
            "error": str(e),
            "meal_sections": [[] for _ in range(num_meals)]
        })

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({"status": "healthy"})

if __name__ == '__main__':
    app.run(debug=True, port=5001)
